(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/BlockLayout.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b2094jTomtJQZGmHwpGwHv2', 'BlockLayout', __filename);
// Script/BlockLayout.js

"use strict";

var Emitter = require('mEmitter');
var Variables = require("./Variables");
var colors = require("./Colors");
cc.Class({
    extends: cc.Component,

    properties: {
        BlockPrefab: cc.Prefabs,
        _flag: false
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        Emitter.instance.emit('transBlockLayout', this);
        // console.log(colors);
        this.gameInit();
    },
    gameInit: function gameInit() {
        this.createBlocks();
        this.data = this.createArray2D(4, 4);
        console.log(this.data);

        this.randomBlock();
        this.randomBlock();
    },
    createArray2D: function createArray2D(row, col) {
        var arr = new Array();
        for (var i = 0; i < row; i++) {
            arr[i] = new Array();
            for (var j = 0; j < col; j++) {
                arr[i][j] = 0;
            }
        }
        return arr;
    },
    createBlocks: function createBlocks() {
        Variables.blocks = this.createArray2D(4, 4);
        for (var row = 0; row < Variables.blocks.length; row++) {
            for (var _col = 0; _col < Variables.blocks.length; _col++) {
                var block = cc.instantiate(this.BlockPrefab);
                this.setLabel(block, 0);
                block.parent = this.node;
                Variables.blocks[row][_col] = block;
            }
        }
    },
    setLabel: function setLabel(block, number) {
        if (number == 0) {
            // block.active = false
            block.getChildByName("BlockLabel").getComponent(cc.Label).string = "";
        } else {
            block.getChildByName("BlockLabel").getComponent(cc.Label).string = number;
        }

        block.color = colors[number];
    },
    getEmptyLocations: function getEmptyLocations() {
        var emptyLocations = [];
        for (var row = 0; row < this.data.length; row++) {
            for (var _col2 = 0; _col2 < this.data.length; _col2++) {
                if (this.data[row][_col2] == 0) {
                    emptyLocations.push({
                        x: row,
                        y: _col2
                    });
                }
            }
        }
        return emptyLocations;
    },
    randomBlock: function randomBlock() {
        var emptyLocations = this.getEmptyLocations();
        var location = emptyLocations[Math.floor(Math.random() * emptyLocations.length)];
        var x = location.x;
        var y = location.y;
        this.data[x][y] = Variables.numbers[Math.floor(Math.random() * Variables.numbers.length)];
        this.setLabel(Variables.blocks[x][y], this.data[x][y]);
    },
    moveRight: function moveRight(row) {
        var col = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 3;

        var isZero = true;
        for (var index = 0; index < this.data[row].length; index++) {
            if (this.data[row][index] != 0) {
                isZero = false;
            }
        }
        if (isZero) {
            return;
        }
        if (col == 0) {
            if (this.data[row][3] == 0) {
                this.moveRight(row, 3);
            }
            if (this.data[row][1] != 0 && this.data[row][3] != 0 && this.data[row][2] == 0) {
                this.moveRight(row, 3);
            }
            this.updateBlockNum();
            if (this._flag) {
                this.mergeBlock(row, "Right");
            }
            return;
        }
        if (this.data[row][col] == 0) {
            this.data[row][col] = this.data[row][col - 1];
            this.data[row][col - 1] = 0;
        }
        this.moveRight(row, col - 1);
        this.updateBlockNum();
    },
    moveUp: function moveUp(col) {
        var row = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

        console.log(row);
        var isZero = true;
        for (var index = 0; index < this.data[col].length; index++) {
            if (this.data[index][col] != 0) {
                isZero = false;
            }
        }
        if (isZero) {
            return;
        }
        if (row == 3) {
            if (this.data[0][col] == 0) {
                this.moveUp(col, 0);
            }
            if (this.data[0][col] != 0 && this.data[2][col] != 0 && this.data[1][col] == 0) {
                this.moveUp(col, 0);
            }
            this.updateBlockNum();
            if (this._flag) {
                this.mergeUp(col);
            }
            return;
        }
        if (this.data[row][col] == 0) {
            this.data[row][col] = this.data[row + 1][col];
            this.data[row + 1][col] = 0;
        }
        this.moveUp(col, row + 1);
        this.updateBlockNum();
    },

    // mergeRight(row) {
    //     this.updateBlockNum();
    //     for (let index = 3; index >= 0; index--) {
    //         if (this.data[row][index] == this.data[row][index -1] && this.data[row][index - 1] != 0 && this.data[row][index] != 0) {
    //             this.data[row][index] *= 2
    //             this.data[row][index - 1] = 0
    //             this.updateBlockNum();
    //             this._flag = false
    //             this.moveRight(row, 3)
    //         }
    //     }


    // },
    // mergeLeft(row) {
    //     this.updateBlockNum();
    //     for (let index = 0; index < 4; index++) {
    //         if (this.data[row][index + 1] == this.data[row][index] && this.data[row][index + 1] != 0 && this.data[row][index] != 0) {
    //             this.data[row][index] *= 2
    //             this.data[row][index + 1] = 0
    //             this.updateBlockNum();
    //             this._flag = false
    //             this.moveLeft(row, 0)
    //         }
    //     }


    // },
    mergeUp: function mergeUp(col) {
        this.updateBlockNum();

        for (var index = 0; index < 4; index++) {
            console.log(index);
            if (this.data[index][col] == this.data[index + 1][col] && this.data[index + 1][col] != 0 && this.data[index][col] != 0) {
                this.data[index][col] *= 2;
                this.data[index + 1][col] = 0;
                this.updateBlockNum();
                this._flag = false;
                this.moveUp(col, 0);
            }
        }
    },
    mergeBlock: function mergeBlock(row, direction) {
        this.updateBlockNum();

        switch (direction) {
            case "Left":
                for (var index = 0; index < 4; index++) {
                    if (this.data[row][index + 1] == this.data[row][index] && this.data[row][index + 1] != 0 && this.data[row][index] != 0) {
                        this.data[row][index] *= 2;
                        this.data[row][index + 1] = 0;
                        this.updateBlockNum();
                        this._flag = false;
                        this.moveLeft(row, 0);
                    }
                }
                break;
            case "Right":
                for (var _index = 3; _index >= 0; _index--) {
                    if (this.data[row][_index] == this.data[row][_index - 1] && this.data[row][_index - 1] != 0 && this.data[row][_index] != 0) {
                        this.data[row][_index] *= 2;
                        this.data[row][_index - 1] = 0;
                        this.updateBlockNum();
                        this._flag = false;
                        this.moveRight(row, 3);
                    }
                }
                break;
            case "Up":
                for (var _index2 = 0; _index2 < 4; _index2++) {
                    if (this.data[row][_index2] == this.data[row][_index2 + 1] && this.data[row][_index2 + 1] != 0 && this.data[row][_index2] != 0) {
                        this.data[row][_index2] *= 2;
                        this.data[row][_index2 + 1] = 0;
                        this.updateBlockNum();
                        this._flag = false;
                        this.moveUp(0, col);
                    }
                }
                break;

            default:
                break;
        }
    },
    moveLeft: function moveLeft(row) {
        var col = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

        var isZero = true;
        for (var index = 0; index < this.data[row].length; index++) {
            if (this.data[row][index] != 0) {
                isZero = false;
            }
        }
        if (isZero) {
            return;
        }
        if (col == 3) {
            if (this.data[row][0] == 0) {
                this.moveLeft(row, 0);
            }
            if (this.data[row][0] != 0 && this.data[row][2] != 0 && this.data[row][1] == 0) {
                this.moveLeft(row, 0);
            }
            this.updateBlockNum();
            if (this._flag) {
                this.mergeBlock(row, "Left");
            }
            return;
        }
        if (this.data[row][col] == 0) {
            this.data[row][col] = this.data[row][col + 1];
            this.data[row][col + 1] = 0;
        }
        this.moveLeft(row, col + 1);
        this.updateBlockNum();
    },


    // moveLeft(row, col = 3) {
    //     // console.log("Move left");
    //     if (col == 0) {
    //         if (this.data[row][3] == 0) {
    //             this.moveRight(row, col = 3)
    //         } else {
    //             return
    //         }

    //     } else {
    //         if (this.data[row][col] == 0) {
    //             this.data[row][col] = this.data[row][col - 1];
    //             this.data[row][col - 1] = 0;
    //             this.moveLeft(row, col - 1);
    //             // this.updateBlockNum(); 
    //         } else {
    //             if (this.data[row][col] == this.data[row][col - 1]) {
    //                 this.data[row][col - 1] *= 2
    //                 this.data[row][col] = 0
    //             } else {
    //                 this.moveLeft(row, col - 1)
    //                 // this.updateBlockNum()
    //             }

    //         }
    //         // this.moveLeft(row, col -1)
    //         this.updateBlockNum();
    //     }
    // },
    moveDown: function moveDown() {
        var row = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
        var col = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

        // console.log("Move Down");
        if (row == Variables.rows - 1) {
            return;
        } else {
            if (this.data[row + 1][col] == 0) {
                this.data[row + 1][col] = this.data[row][col];
                this.data[row][col] = 0;
                this.moveDown(row + 1, col);
                this.updateBlockNum();
            } else {
                if (this.data[row][col] == this.data[row + 1][col]) {
                    this.data[row + 1][col] *= 2;
                    this.data[row][col] = 0;
                }
                this.moveDown(row + 1, col);
                this.updateBlockNum();
            }
        }
    },

    // moveUp(row = 0, col = 0) {
    //     // console.log("Move Down");
    //     if (row == 0) {
    //         return;
    //     } else {
    //         if (this.data[row - 1][col] == 0) {
    //             this.data[row - 1][col] = this.data[row][col];
    //             this.data[row][col] = 0
    //             this.moveUp(row - 1, col)
    //             this.updateBlockNum()
    //         } else {
    //             if (this.data[row][col] == this.data[row - 1][col]) {
    //                 this.data[row - 1][col] *= 2
    //                 this.data[row][col] = 0
    //             }
    //             this.moveUp(row - 1, col)
    //             this.updateBlockNum()
    //         }

    //     }
    // },
    updateBlockNum: function updateBlockNum() {
        // 更新方块数字
        for (var row = 0; row < 4; row++) {
            for (var _col3 = 0; _col3 < 4; _col3++) {
                this.setLabel(Variables.blocks[row][_col3], this.data[row][_col3]);
            }
        }
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BlockLayout.js.map
        