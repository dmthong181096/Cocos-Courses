"use strict";
cc._RF.push(module, 'b4d158gDSNI8pevI+gIvsWl', 'Game');
// Script/Game.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
var Emitter = require('mEmitter');
var Variables = require('Variables');
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        // cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        Emitter.instance = new Emitter();
        // Emitter.instance.registerEvent("HELLO", this.onHello.bind(this));
        Emitter.instance.registerEvent("transBlockLayout", this.transBlockLayout, this);
        Emitter.instance.registerEvent("transScore", this.transScore, this);
        Emitter.instance.registerEvent("transBestScore", this.transBestScore, this);
    },
    onDestroy: function onDestroy() {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        // cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    },
    transBlockLayout: function transBlockLayout(data) {
        Variables.blockLayout = data;
    },
    transScore: function transScore(data) {
        Variables.score = data;
    },
    transBestScore: function transBestScore(data) {
        Variables.bestScore = data;
    },
    start: function start() {
        // console.log( Variables.score.node);
        this.init();
    },
    init: function init() {
        Variables.score.updateScore(10);
        Variables.bestScore.updateBestScore(20);
    },


    onKeyDown: function onKeyDown(event) {
        switch (event.keyCode) {
            case cc.macro.KEY.down:
                console.log('Press a key DOWN');
                for (var col = 0; col < 4; col++) {
                    Variables.blockLayout._flag = true;
                    Variables.blockLayout.moveDown(0, col);
                }
                break;
            case cc.macro.KEY.up:
                console.log('Press a key UP');
                for (var _col = 0; _col < 4; _col++) {
                    Variables.blockLayout._flag = true;
                    Variables.blockLayout.moveUp(_col);
                }
                Variables.blockLayout.randomBlock();
                break;
            case cc.macro.KEY.left:
                console.log('Press a key LEFT');
                for (var row = 0; row < 4; row++) {
                    Variables.blockLayout._flag = true;
                    Variables.blockLayout.moveLeft(row);
                }
                Variables.blockLayout.randomBlock();
                break;
            case cc.macro.KEY.right:
                console.log('Press a key RIGHT');
                for (var _row = 0; _row < 4; _row++) {
                    // console.log(row);
                    Variables.blockLayout._flag = true;
                    Variables.blockLayout.moveRight(_row);
                }
                Variables.blockLayout.randomBlock();
                break;
            default:
                {
                    return;
                }

        }
    }
    // update (dt) {},
});

cc._RF.pop();